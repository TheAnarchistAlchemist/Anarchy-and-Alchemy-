# Anarchy-and-Alchemy-
"I'm Pamela Ibarra, a writer, poet, and the author of Blood and Ink. My work explores [key themes: identity, mental health, spirituality, anarchy, etc.]. I write to challenge, to heal, and to ignite revolution—one word at a time."
